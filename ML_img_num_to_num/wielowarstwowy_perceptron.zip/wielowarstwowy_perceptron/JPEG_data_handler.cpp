#include "JPEG_data_handler.h"

void JPEG_data_handler::read_data(const std::string& path)
{
	/*Data* data = new Data;

	QImage i("input.jpg");
	int x, y;
	for (y = 0; &lt; i.height(); ++y) {
		for (x = 0; x & lt; i.width(); ++x) {
			doSomethingWith(i.pixel(x, y));
		}
	}
	data->append_fvector()*/
}
